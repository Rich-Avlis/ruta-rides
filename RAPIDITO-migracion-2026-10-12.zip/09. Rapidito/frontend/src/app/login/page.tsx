'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';

function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      router.push('/dashboard');
    } catch (error) {
      // Error handled by context
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-2xl">
              R
            </div>
            <span className="text-2xl font-bold">RAPIDITO</span>
          </Link>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h1 className="text-2xl font-bold text-center mb-2">Iniciar Sesión</h1>
          <p className="text-gray-500 text-center mb-6">
            ¿No tienes cuenta?{' '}
            <Link href="/register" className="text-orange-500 font-medium hover:underline">
              Regístrate
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Correo electrónico
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field"
                placeholder="tu@email.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contraseña
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="input-field"
                placeholder="••••••••"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary disabled:opacity-50"
            >
              {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
            </button>
          </form>

          {/* Demo users */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center mb-3">Usuarios de prueba:</p>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                onClick={() => { setEmail('jose@test.com'); setPassword('123456'); }}
                className="bg-gray-100 hover:bg-gray-200 px-2 py-2 rounded text-center transition-colors"
              >
                <span className="font-medium">Pasajero</span>
              </button>
              <button
                onClick={() => { setEmail('carlos@test.com'); setPassword('123456'); }}
                className="bg-gray-100 hover:bg-gray-200 px-2 py-2 rounded text-center transition-colors"
              >
                <span className="font-medium">Conductor</span>
              </button>
              <button
                onClick={() => { setEmail('admin@rapidito.com'); setPassword('admin123'); }}
                className="bg-gray-100 hover:bg-gray-200 px-2 py-2 rounded text-center transition-colors"
              >
                <span className="font-medium">Admin</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <AuthProvider>
      <LoginForm />
    </AuthProvider>
  );
}