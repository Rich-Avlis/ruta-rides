'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import Header from '@/components/Header';
import api from '@/lib/api';

function DashboardContent() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [rides, setRides] = useState<any[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      const response = await api.get('/api/rides/my-rides');
      setRides(response.data.rides || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoadingData(false);
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  const completedRides = rides.filter(r => r.estado === 'COMPLETED').length;
  const activeRides = rides.filter(r => ['REQUESTED', 'SEARCHING_DRIVER', 'DRIVER_ASSIGNED', 'TRIP_STARTED'].includes(r.estado)).length;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {/* Welcome */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold">¡Hola, {user.nombre}! 👋</h1>
          <p className="text-gray-500">
            {user.rol === 'PASSENGER' && 'Bienvenido a tu panel de viajes'}
            {user.rol === 'DRIVER' && 'Bienvenido a tu panel de conductor'}
            {user.rol === 'ADMIN' && 'Panel de administración'}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-5 border-l-4 border-orange-500">
            <p className="text-sm text-gray-500">Total Viajes</p>
            <p className="text-2xl font-bold">{rides.length}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-5 border-l-4 border-green-500">
            <p className="text-sm text-gray-500">Completados</p>
            <p className="text-2xl font-bold">{completedRides}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-5 border-l-4 border-yellow-500">
            <p className="text-sm text-gray-500">Activos</p>
            <p className="text-2xl font-bold">{activeRides}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm p-5 border-l-4 border-orange-500">
            <p className="text-sm text-gray-500">Calificación</p>
            <p className="text-2xl font-bold">4.9 ⭐</p>
          </div>
        </div>

        {/* Quick Actions */}
        {user.rol === 'PASSENGER' && (
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <button className="bg-gradient-to-r from-orange-500 to-orange-600 text-white rounded-xl p-6 text-left hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-2">🚗</div>
              <h3 className="text-lg font-bold">Solicitar Viaje</h3>
              <p className="text-sm text-white/80">Encuentra conductores cercanos</p>
            </button>
            <button className="bg-white rounded-xl p-6 text-left hover:shadow-lg transition-shadow border border-gray-200">
              <div className="text-4xl mb-2">📍</div>
              <h3 className="text-lg font-bold">Historial</h3>
              <p className="text-sm text-gray-500">Revisa tus viajes anteriores</p>
            </button>
          </div>
        )}

        {user.rol === 'DRIVER' && (
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <button className="bg-gradient-to-r from-green-500 to-green-600 text-white rounded-xl p-6 text-left hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-2">🟢</div>
              <h3 className="text-lg font-bold">Ponerse en Línea</h3>
              <p className="text-sm text-white/80">Comienza a recibir viajes</p>
            </button>
            <button className="bg-white rounded-xl p-6 text-left hover:shadow-lg transition-shadow border border-gray-200">
              <div className="text-4xl mb-2">📊</div>
              <h3 className="text-lg font-bold">Mis Ganancias</h3>
              <p className="text-sm text-gray-500">Revisa tus ingresos</p>
            </button>
          </div>
        )}

        {/* Recent Rides */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-bold mb-4">📋 Viajes Recientes</h2>
          
          {rides.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <div className="text-5xl mb-4">🚗</div>
              <p>No tienes viajes recientes</p>
            </div>
          ) : (
            <div className="space-y-3">
              {rides.slice(0, 5).map((ride) => (
                <div key={ride.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="text-2xl">
                      {ride.estado === 'COMPLETED' ? '✅' : 
                       ride.estado === 'CANCELLED' ? '❌' : '⏳'}
                    </div>
                    <div>
                      <p className="font-medium">
                        {ride.origenDireccion || 'Origen'} → {ride.destinoDireccion || 'Destino'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(ride.createdAt).toLocaleDateString('es-VE')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-orange-500">${ride.tarifaFinal}</p>
                    <p className="text-xs text-gray-500">{ride.estado}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

export default function DashboardPage() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  );
}