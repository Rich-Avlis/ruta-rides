'use client';

import Link from 'next/link';
import { AuthProvider } from '@/contexts/AuthContext';
import Header from '@/components/Header';

function HomePage() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        {/* Hero */}
        <section className="bg-gradient-to-br from-orange-500 to-orange-600 text-white py-20">
          <div className="container mx-auto px-4 text-center">
            <span className="inline-block bg-white/20 px-4 py-2 rounded-full text-sm mb-6">
              Disponible en Quíbor, Lara
            </span>
            
            <h1 className="text-5xl font-bold mb-6">
              Tu viaje, <span className="text-yellow-300">rápido</span> y <span className="text-yellow-300">seguro</span>
            </h1>
            
            <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
              Conectamos pasajeros con conductores de confianza. Solicita tu viaje en segundos.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register?role=PASSENGER">
                <button className="bg-white text-orange-500 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition-colors">
                  🚗 Solicitar Viaje
                </button>
              </Link>
              <Link href="/register?role=DRIVER">
                <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-white hover:text-orange-500 transition-colors">
                  🏍️ Ser Conductor
                </button>
              </Link>
            </div>
            
            <div className="flex justify-center gap-12 mt-12">
              <div>
                <p className="text-3xl font-bold">100+</p>
                <p className="text-white/80">Viajes</p>
              </div>
              <div>
                <p className="text-3xl font-bold">50+</p>
                <p className="text-white/80">Conductores</p>
              </div>
              <div>
                <p className="text-3xl font-bold">4.9⭐</p>
                <p className="text-white/80">Calificación</p>
              </div>
            </div>
          </div>
        </section>

        {/* Cómo funciona */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">¿Cómo funciona?</h2>
            
            <div className="grid md:grid-cols-4 gap-8">
              {[
                { num: 1, icon: '📍', title: 'Destino', desc: 'Selecciona tu punto de recogida y destino' },
                { num: 2, icon: '💰', title: 'Precio', desc: 'El sistema calcula la tarifa automáticamente' },
                { num: 3, icon: '🤝', title: 'Negocia', desc: 'Ofrece un precio o acepta la tarifa' },
                { num: 4, icon: '🏍️', title: 'Viaja', desc: 'Sigue al conductor en tiempo real' },
              ].map((step) => (
                <div key={step.num} className="text-center">
                  <div className="w-16 h-16 bg-orange-100 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-4">
                    {step.icon}
                  </div>
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-white text-xs font-bold mx-auto -mt-3 mb-2">
                    {step.num}
                  </div>
                  <h3 className="font-bold text-lg mb-2">{step.title}</h3>
                  <p className="text-gray-600 text-sm">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Beneficios */}
        <section className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">¿Por qué RAPIDITO?</h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: '⚡', title: 'Rápido', desc: 'Encuentra conductores cercanos en minutos' },
                { icon: '🛡️', title: 'Seguro', desc: 'Conductores verificados y documentos validados' },
                { icon: '💰', title: 'Económico', desc: 'Tarifas justas con opción de negociar' },
              ].map((feature, i) => (
                <div key={i} className="bg-white rounded-xl shadow-lg p-8 text-center">
                  <div className="text-5xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-center">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">¿Listo para viajar?</h2>
            <p className="text-white/90 mb-8">Únete a miles de personas que ya confían en RAPIDITO</p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register?role=PASSENGER">
                <button className="bg-white text-orange-500 px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition-colors">
                  🚗 Quiero viajar
                </button>
              </Link>
              <Link href="/register?role=DRIVER">
                <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white hover:text-orange-500 transition-colors">
                  🏍️ Quiero conducir
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-8">
          <div className="container mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center font-bold">R</div>
              <span className="text-xl font-bold">RAPIDITO</span>
            </div>
            <p className="text-gray-400">© 2026 RAPIDITO. Quíbor, Lara, Venezuela</p>
          </div>
        </footer>
      </div>
    </AuthProvider>
  );
}

export default HomePage;