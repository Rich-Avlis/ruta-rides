'use client';

import Link from 'next/link';
import { useAuth } from '@/contexts/AuthContext';

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-orange-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">
            R
          </div>
          <span className="text-xl font-bold">RAPIDITO</span>
        </Link>

        <nav className="flex items-center gap-4">
          {user ? (
            <>
              <Link href="/dashboard" className="text-gray-600 hover:text-orange-500">
                Dashboard
              </Link>
              <span className="text-sm text-gray-500">{user.nombre}</span>
              <button onClick={logout} className="text-sm text-gray-500 hover:text-orange-500">
                Salir
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-gray-600 hover:text-orange-500">
                Iniciar Sesión
              </Link>
              <Link href="/register">
                <button className="bg-orange-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-600 transition-colors">
                  Registrarse
                </button>
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}