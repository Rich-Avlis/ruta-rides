const socketIo = require('socket.io');
const jwt = require('jsonwebtoken');

let io;

const initializeSocket = (server) => {
  io = socketIo(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('Token requerido'));
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.userId;
      next();
    } catch (err) {
      next(new Error('Token inválido'));
    }
  });

  io.on('connection', (socket) => {
    console.log(`🔌 Usuario conectado: ${socket.userId}`);

    socket.on('join-ride', (rideId) => {
      socket.join(`ride-${rideId}`);
      console.log(`👥 Usuario ${socket.userId} se unió al viaje ${rideId}`);
    });

    socket.on('leave-ride', (rideId) => {
      socket.leave(`ride-${rideId}`);
      console.log(`👋 Usuario ${socket.userId} salió del viaje ${rideId}`);
    });

    socket.on('update-location', (data) => {
      const { rideId, lat, lng } = data;
      io.to(`ride-${rideId}`).emit('location-updated', {
        userId: socket.userId,
        lat,
        lng,
        timestamp: new Date()
      });
    });

    socket.on('ride-status-changed', (data) => {
      const { rideId, status } = data;
      io.to(`ride-${rideId}`).emit('status-changed', {
        rideId,
        status,
        timestamp: new Date()
      });
    });

    socket.on('new-offer', (data) => {
      const { rideId, offer } = data;
      io.to(`ride-${rideId}`).emit('offer-received', {
        rideId,
        offer,
        timestamp: new Date()
      });
    });

    socket.on('counter-offer', (data) => {
      const { rideId, offer } = data;
      io.to(`ride-${rideId}`).emit('counter-offer-received', {
        rideId,
        offer,
        timestamp: new Date()
      });
    });

    socket.on('driver-arriving', (data) => {
      const { rideId, eta } = data;
      io.to(`ride-${rideId}`).emit('driver-arriving-notification', {
        rideId,
        eta,
        timestamp: new Date()
      });
    });

    socket.on('disconnect', () => {
      console.log(`🔌 Usuario desconectado: ${socket.userId}`);
    });
  });

  return io;
};

const getIO = () => {
  if (!io) {
    throw new Error('Socket.IO no está inicializado');
  }
  return io;
};

module.exports = { initializeSocket, getIO };