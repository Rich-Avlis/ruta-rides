const { Op } = require('sequelize');
const Ride = require('../models/Ride');
const User = require('../models/User');
const DriverProfile = require('../models/DriverProfile');
const Negotiation = require('../models/Negotiation');

exports.findNearbyDrivers = async (req, res) => {
  try {
    const { lat, lng, radio = 5 } = req.query;

    if (!lat || !lng) {
      return res.status(400).json({ error: 'Latitud y longitud son requeridas' });
    }

    const latNum = parseFloat(lat);
    const lngNum = parseFloat(lng);
    const radioKm = parseFloat(radio);

    const latMin = latNum - (radioKm / 111);
    const latMax = latNum + (radioKm / 111);
    const lngMin = lngNum - (radioKm / (111 * Math.cos(latNum * Math.PI / 180)));
    const lngMax = lngNum + (radioKm / (111 * Math.cos(latNum * Math.PI / 180)));

    const drivers = await DriverProfile.findAll({
      where: {
        enLinea: true,
        ubicacionLat: { [Op.between]: [latMin, latMax] },
        ubicacionLng: { [Op.between]: [lngMin, lngMax] }
      },
      include: [{
        model: User,
        as: 'user',
        attributes: ['id', 'nombre', 'apellido', 'foto']
      }]
    });

    const driversWithDistance = drivers.map(driver => {
      const distance = Math.sqrt(
        Math.pow((driver.ubicacionLat - latNum) * 111, 2) +
        Math.pow((driver.ubicacionLng - lngNum) * 111 * Math.cos(latNum * Math.PI / 180), 2)
      );

      const eta = Math.round(distance * 3);

      return {
        id: driver.userId,
        nombre: driver.user.nombre,
        apellido: driver.user.apellido,
        foto: driver.user.foto,
        calificacion: driver.calificacion,
        cantidadViajes: driver.cantidadViajes,
        tipoVehiculo: driver.tipoVehiculo,
        marcaVehiculo: driver.marcaVehiculo,
        modeloVehiculo: driver.modeloVehiculo,
        colorVehiculo: driver.colorVehiculo,
        distancia: Math.round(distance * 100) / 100,
        eta: eta,
        ubicacionLat: driver.ubicacionLat,
        ubicacionLng: driver.ubicacionLng
      };
    });

    driversWithDistance.sort((a, b) => a.distancia - b.distancia);

    res.json({
      conductores: driversWithDistance,
      total: driversWithDistance.length
    });
  } catch (error) {
    console.error('Error al buscar conductores cercanos:', error);
    res.status(500).json({ error: 'Error al buscar conductores' });
  }
};

exports.requestRide = async (req, res) => {
  try {
    const { 
      origenLat, origenLng, origenDireccion,
      destinoLat, destinoLng, destinoDireccion,
      distancia, tiempoEstimado, tarifaBase, precioOfrecido,
      metodoPago
    } = req.body;

    const ride = await Ride.create({
      pasajeroId: req.user.id,
      estado: 'SEARCHING_DRIVER',
      origenLat,
      origenLng,
      origenDireccion,
      destinoLat,
      destinoLng,
      destinoDireccion,
      distancia,
      tiempoEstimado,
      tarifaBase,
      tarifaFinal: precioOfrecido || tarifaBase,
      precioOfrecido,
      metodoPago
    });

    res.status(201).json({
      message: 'Viaje solicitado exitosamente',
      ride
    });
  } catch (error) {
    console.error('Error al solicitar viaje:', error);
    res.status(500).json({ error: 'Error al solicitar viaje' });
  }
};

exports.acceptRide = async (req, res) => {
  try {
    const { rideId } = req.params;

    const ride = await Ride.findByPk(rideId);

    if (!ride) {
      return res.status(404).json({ error: 'Viaje no encontrado' });
    }

    if (ride.estado !== 'SEARCHING_DRIVER') {
      return res.status(400).json({ error: 'Este viaje ya fue asignado' });
    }

    await ride.update({
      conductorId: req.user.id,
      estado: 'DRIVER_ASSIGNED'
    });

    res.json({
      message: 'Viaje aceptado',
      ride
    });
  } catch (error) {
    console.error('Error al aceptar viaje:', error);
    res.status(500).json({ error: 'Error al aceptar viaje' });
  }
};

exports.updateRideStatus = async (req, res) => {
  try {
    const { rideId } = req.params;
    const { estado } = req.body;

    const ride = await Ride.findByPk(rideId);

    if (!ride) {
      return res.status(404).json({ error: 'Viaje no encontrado' });
    }

    await ride.update({ estado });

    res.json({
      message: 'Estado del viaje actualizado',
      ride
    });
  } catch (error) {
    console.error('Error al actualizar viaje:', error);
    res.status(500).json({ error: 'Error al actualizar viaje' });
  }
};

exports.getMyRides = async (req, res) => {
  try {
    const rides = await Ride.findAll({
      where: {
        [Op.or]: [
          { pasajeroId: req.user.id },
          { conductorId: req.user.id }
        ]
      },
      order: [['createdAt', 'DESC']],
      limit: 20
    });

    res.json({ rides });
  } catch (error) {
    console.error('Error al obtener viajes:', error);
    res.status(500).json({ error: 'Error al obtener viajes' });
  }
};

exports.getRideById = async (req, res) => {
  try {
    const { rideId } = req.params;

    const ride = await Ride.findByPk(rideId);

    if (!ride) {
      return res.status(404).json({ error: 'Viaje no encontrado' });
    }

    res.json({ ride });
  } catch (error) {
    console.error('Error al obtener viaje:', error);
    res.status(500).json({ error: 'Error al obtener viaje' });
  }
};

exports.makeOffer = async (req, res) => {
  try {
    const { rideId } = req.params;
    const { monto } = req.body;

    const ride = await Ride.findByPk(rideId);

    if (!ride) {
      return res.status(404).json({ error: 'Viaje no encontrado' });
    }

    const negotiation = await Negotiation.create({
      rideId,
      usuarioId: req.user.id,
      monto,
      tipo: 'OFERTA',
      estado: 'PENDIENTE'
    });

    res.status(201).json({
      message: 'Oferta realizada',
      negotiation
    });
  } catch (error) {
    console.error('Error al ofrecer:', error);
    res.status(500).json({ error: 'Error al realizar oferta' });
  }
};

exports.counterOffer = async (req, res) => {
  try {
    const { rideId } = req.params;
    const { monto } = req.body;

    const ride = await Ride.findByPk(rideId);

    if (!ride) {
      return res.status(404).json({ error: 'Viaje no encontrado' });
    }

    const negotiation = await Negotiation.create({
      rideId,
      usuarioId: req.user.id,
      monto,
      tipo: 'CONTRAOFERTA',
      estado: 'PENDIENTE'
    });

    res.status(201).json({
      message: 'Contraoferta realizada',
      negotiation
    });
  } catch (error) {
    console.error('Error al contraofertar:', error);
    res.status(500).json({ error: 'Error al realizar contraoferta' });
  }
};

exports.goOnline = async (req, res) => {
  try {
    const { lat, lng } = req.body;

    if (!lat || !lng) {
      return res.status(400).json({ error: 'Ubicación requerida' });
    }

    const profile = await DriverProfile.findOne({
      where: { userId: req.user.id }
    });

    if (!profile) {
      return res.status(404).json({ error: 'Perfil de conductor no encontrado' });
    }

    await profile.update({
      enLinea: true,
      ubicacionLat: lat,
      ubicacionLng: lng
    });

    res.json({
      message: 'Conectado exitosamente',
      enLinea: true
    });
  } catch (error) {
    console.error('Error al conectar:', error);
    res.status(500).json({ error: 'Error al conectar' });
  }
};

exports.goOffline = async (req, res) => {
  try {
    const profile = await DriverProfile.findOne({
      where: { userId: req.user.id }
    });

    if (!profile) {
      return res.status(404).json({ error: 'Perfil de conductor no encontrado' });
    }

    await profile.update({
      enLinea: false
    });

    res.json({
      message: 'Desconectado',
      enLinea: false
    });
  } catch (error) {
    console.error('Error al desconectar:', error);
    res.status(500).json({ error: 'Error al desconectar' });
  }
};

exports.updateLocation = async (req, res) => {
  try {
    const { lat, lng } = req.body;

    if (!lat || !lng) {
      return res.status(400).json({ error: 'Ubicación requerida' });
    }

    const profile = await DriverProfile.findOne({
      where: { userId: req.user.id }
    });

    if (!profile) {
      return res.status(404).json({ error: 'Perfil de conductor no encontrado' });
    }

    await profile.update({
      ubicacionLat: lat,
      ubicacionLng: lng
    });

    res.json({
      message: 'Ubicación actualizada'
    });
  } catch (error) {
    console.error('Error al actualizar ubicación:', error);
    res.status(500).json({ error: 'Error al actualizar ubicación' });
  }
};