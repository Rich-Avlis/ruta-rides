const { Op } = require('sequelize');
const sequelize = require('../config/database');
const User = require('../models/User');
const Ride = require('../models/Ride');
const DriverProfile = require('../models/DriverProfile');
const PassengerProfile = require('../models/PassengerProfile');
const Payment = require('../models/Payment');
const DriverDocument = require('../models/DriverDocument');
const Zone = require('../models/Zone');
const Route = require('../models/Route');
const SystemConfig = require('../models/SystemConfig');

exports.getDashboard = async (req, res) => {
  try {
    const totalUsers = await User.count();
    const totalPassengers = await User.count({ where: { rol: 'PASSENGER' } });
    const totalDrivers = await User.count({ where: { rol: 'DRIVER' } });
    
    const driversOnline = await DriverProfile.count({ where: { enLinea: true } });
    
    const totalRides = await Ride.count();
    const completedRides = await Ride.count({ where: { estado: 'COMPLETED' } });
    const cancelledRides = await Ride.count({ where: { estado: 'CANCELLED' } });
    const activeRides = await Ride.count({ 
      where: { 
        estado: { 
          [Op.in]: ['REQUESTED', 'SEARCHING_DRIVER', 'DRIVER_ASSIGNED', 'DRIVER_EN_ROUTE', 'TRIP_STARTED'] 
        } 
      } 
    });

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const ridesToday = await Ride.count({
      where: {
        createdAt: { [Op.gte]: today }
      }
    });

    const totalRevenue = await Payment.sum('monto', {
      where: { estado: 'COMPLETADO' }
    }) || 0;

    const revenueToday = await Payment.sum('monto', {
      where: { 
        estado: 'COMPLETADO',
        createdAt: { [Op.gte]: today }
      }
    }) || 0;

    const pendingDocuments = await DriverDocument.count({
      where: { estado: 'PENDIENTE' }
    });

    const recentRides = await Ride.findAll({
      include: [
        { model: User, as: 'pasajero', attributes: ['nombre', 'apellido'] },
        { model: User, as: 'conductor', attributes: ['nombre', 'apellido'] }
      ],
      order: [['createdAt', 'DESC']],
      limit: 10
    });

    res.json({
      estadisticas: {
        usuarios: {
          total: totalUsers,
          pasajeros: totalPassengers,
          conductores: totalDrivers
        },
        conductores: {
          enLinea: driversOnline
        },
      viajes: {
          total: totalRides,
          completados: completedRides,
          cancelados: cancelledRides,
          activos: activeRides,
          hoy: ridesToday
        },
        ingresos: {
          total: Math.round(totalRevenue * 100) / 100,
          hoy: Math.round(revenueToday * 100) / 100
        },
        documentos: {
          pendientes: pendingDocuments
        }
      },
      viajesRecientes: recentRides
    });
  } catch (error) {
    console.error('Error al obtener dashboard:', error);
    res.status(500).json({ error: 'Error al obtener estadísticas' });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const { page = 1, limit = 20, rol, search } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (rol) where.rol = rol;
    if (search) {
      where[Op.or] = [
        { nombre: { [Op.like]: `%${search}%` } },
        { apellido: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } }
      ];
    }

    const users = await User.findAndCountAll({
      where,
      attributes: { exclude: ['password'] },
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      usuarios: users.rows,
      total: users.count,
      paginas: Math.ceil(users.count / limit)
    });
  } catch (error) {
    console.error('Error al obtener usuarios:', error);
    res.status(500).json({ error: 'Error al obtener usuarios' });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const updates = req.body;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    delete updates.password;
    delete updates.rol;

    await user.update(updates);

    res.json({
      message: 'Usuario actualizado',
      user
    });
  } catch (error) {
    console.error('Error al actualizar usuario:', error);
    res.status(500).json({ error: 'Error al actualizar usuario' });
  }
};

exports.toggleUserStatus = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    await user.update({ activo: !user.activo });

    res.json({
      message: user.activo ? 'Usuario activado' : 'Usuario desactivado',
      user
    });
  } catch (error) {
    console.error('Error al cambiar estado:', error);
    res.status(500).json({ error: 'Error al cambiar estado' });
  }
};

exports.getRides = async (req, res) => {
  try {
    const { page = 1, limit = 20, estado, fechaInicio, fechaFin } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (estado) where.estado = estado;
    if (fechaInicio && fechaFin) {
      where.createdAt = {
        [Op.between]: [new Date(fechaInicio), new Date(fechaFin)]
      };
    }

    const rides = await Ride.findAndCountAll({
      where,
      include: [
        { model: User, as: 'pasajero', attributes: ['id', 'nombre', 'apellido', 'telefono'] },
        { model: User, as: 'conductor', attributes: ['id', 'nombre', 'apellido', 'telefono'] }
      ],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      viajes: rides.rows,
      total: rides.count,
      paginas: Math.ceil(rides.count / limit)
    });
  } catch (error) {
    console.error('Error al obtener viajes:', error);
    res.status(500).json({ error: 'Error al obtener viajes' });
  }
};

exports.getPayments = async (req, res) => {
  try {
    const { page = 1, limit = 20, estado, metodo } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (estado) where.estado = estado;
    if (metodo) where.metodo = metodo;

    const payments = await Payment.findAndCountAll({
      where,
      include: [
        { model: User, attributes: ['id', 'nombre', 'apellido'] },
        { model: Ride, attributes: ['id', 'origenDireccion', 'destinoDireccion'] }
      ],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

    res.json({
      pagos: payments.rows,
      total: payments.count,
      paginas: Math.ceil(payments.count / limit)
    });
  } catch (error) {
    console.error('Error al obtener pagos:', error);
    res.status(500).json({ error: 'Error al obtener pagos' });
  }
};

exports.getConfig = async (req, res) => {
  try {
    const configs = await SystemConfig.findAll();
    
    const configObject = {};
    configs.forEach(c => {
      configObject[c.clave] = c.valor;
    });

    res.json({ configuracion: configObject });
  } catch (error) {
    console.error('Error al obtener configuración:', error);
    res.status(500).json({ error: 'Error al obtener configuración' });
  }
};

exports.updateConfig = async (req, res) => {
  try {
    const { configs } = req.body;

    for (const [clave, valor] of Object.entries(configs)) {
      await SystemConfig.upsert({
        clave,
        valor: String(valor),
        categoria: 'GENERAL'
      });
    }

    res.json({ message: 'Configuración actualizada' });
  } catch (error) {
    console.error('Error al actualizar configuración:', error);
    res.status(500).json({ error: 'Error al actualizar configuración' });
  }
};

exports.getZones = async (req, res) => {
  try {
    const zones = await Zone.findAll();
    res.json({ zonas: zones });
  } catch (error) {
    console.error('Error al obtener zonas:', error);
    res.status(500).json({ error: 'Error al obtener zonas' });
  }
};

exports.createZone = async (req, res) => {
  try {
    const { nombre, descripcion, tipo, coordinates, multiplicador, color } = req.body;

    const zone = await Zone.create({
      nombre,
      descripcion,
      tipo,
      coordinates,
      multiplicador,
      color
    });

    res.status(201).json({
      message: 'Zona creada',
      zona: zone
    });
  } catch (error) {
    console.error('Error al crear zona:', error);
    res.status(500).json({ error: 'Error al crear zona' });
  }
};

exports.updateZone = async (req, res) => {
  try {
    const { zoneId } = req.params;
    const updates = req.body;

    const zone = await Zone.findByPk(zoneId);
    if (!zone) {
      return res.status(404).json({ error: 'Zona no encontrada' });
    }

    await zone.update(updates);

    res.json({
      message: 'Zona actualizada',
      zona: zone
    });
  } catch (error) {
    console.error('Error al actualizar zona:', error);
    res.status(500).json({ error: 'Error al actualizar zona' });
  }
};

exports.getRoutes = async (req, res) => {
  try {
    const routes = await Route.findAll({
      order: [['vecesUsada', 'DESC']]
    });
    res.json({ rutas: routes });
  } catch (error) {
    console.error('Error al obtener rutas:', error);
    res.status(500).json({ error: 'Error al obtener rutas' });
  }
};

exports.createRoute = async (req, res) => {
  try {
    const route = await Route.create(req.body);

    res.status(201).json({
      message: 'Ruta creada',
      ruta: route
    });
  } catch (error) {
    console.error('Error al crear ruta:', error);
    res.status(500).json({ error: 'Error al crear ruta' });
  }
};