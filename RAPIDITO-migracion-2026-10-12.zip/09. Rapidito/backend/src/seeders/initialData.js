const SystemConfig = require('../models/SystemConfig');
const Fare = require('../models/Fare');
const Zone = require('../models/Zone');

const initialConfig = [
  { clave: 'APP_NAME', valor: 'RAPIDITO', categoria: 'GENERAL' },
  { clave: 'APP_VERSION', valor: '1.0.0', categoria: 'GENERAL' },
  { clave: 'CIUDAD_DEFAULT', valor: 'Quíbor', categoria: 'UBICACION' },
  { clave: 'ESTADO_DEFAULT', valor: 'Lara', categoria: 'UBICACION' },
  { clave: 'PAIS_DEFAULT', valor: 'Venezuela', categoria: 'UBICACION' },
  { clave: 'MONEDA', valor: 'USD', categoria: 'PAGO' },
  { clave: 'RADIO_BUSQUEDA_DEFAULT', valor: '5', categoria: 'BUSQUEDA' },
  { clave: 'MULTIPLICADOR_NOCURNO', valor: '1.5', categoria: 'TARIFA' },
  { clave: 'HORA_INICIO_NOCURNO', valor: '22', categoria: 'TARIFA' },
  { clave: 'HORA_FIN_NOCURNO', valor: '5', categoria: 'TARIFA' },
  { clave: 'LIMITE_NEGOCIACIONES', valor: '3', categoria: 'NEGOCIACION' },
  { clave: 'TIEMPO_EXPIRACION_OFERTA', valor: '60', categoria: 'NEGOCIACION' },
  { clave: 'VERIFICACION_DOCUMENTOS_REQUERIDA', valor: 'true', categoria: 'SEGURIDAD' },
  { clave: 'CALIFICACION_MINIMA_CONDUCTOR', valor: '4.0', categoria: 'SEGURIDAD' },
  { clave: 'MAX_VIAJES_CANCELADOS', valor: '5', categoria: 'SEGURIDAD' }
];

const initialFares = [
  {
    nombre: 'Tarifa Urbana Quíbor',
    tipo: 'URBANA',
    tarifaBase: 1.00,
    precioPorKm: 0.50,
    precioPorMinuto: 0.10,
    tarifaMinima: 1.00,
    multiplicadorNocturno: 1.5
  },
  {
    nombre: 'Tarifa Suburbana',
    tipo: 'SUBURBANA',
    tarifaBase: 1.50,
    precioPorKm: 0.75,
    precioPorMinuto: 0.15,
    tarifaMinima: 1.50,
    multiplicadorNocturno: 1.5
  },
  {
    nombre: 'Tarifa Interurbana',
    tipo: 'INTERURBANA',
    tarifaBase: 2.00,
    precioPorKm: 1.00,
    precioPorMinuto: 0.20,
    tarifaMinima: 2.00,
    multiplicadorNocturno: 1.5
  }
];

const initialZones = [
  {
    nombre: 'Centro Quíbor',
    tipo: 'URBANA',
    coordinates: {
      type: 'polygon',
      coordinates: [[[-69.3653, 10.0458], [-69.3600, 10.0458], [-69.3600, 10.0500], [-69.3653, 10.0500], [-69.3653, 10.0458]]]
    },
    multiplicador: 1.0,
    color: '#FF6B00'
  },
  {
    nombre: 'Urb. Jacinto Lara',
    tipo: 'URBANA',
    coordinates: {
      type: 'polygon',
      coordinates: [[[-69.3700, 10.0400], [-69.3650, 10.0400], [-69.3650, 10.0450], [-69.3700, 10.0450], [-69.3700, 10.0400]]]
    },
    multiplicador: 1.0,
    color: '#FF8C33'
  }
];

const seedInitialData = async () => {
  try {
    // Configuración
    for (const config of initialConfig) {
      await SystemConfig.findOrCreate({
        where: { clave: config.clave },
        defaults: config
      });
    }
    console.log('✅ Configuración inicial creada');

    // Tarifas
    for (const fare of initialFares) {
      await Fare.findOrCreate({
        where: { tipo: fare.tipo },
        defaults: fare
      });
    }
    console.log('✅ Tarifas iniciales creadas');

    // Zonas
    for (const zone of initialZones) {
      await Zone.findOrCreate({
        where: { nombre: zone.nombre },
        defaults: zone
      });
    }
    console.log('✅ Zonas iniciales creadas');

  } catch (error) {
    console.error('Error al crear datos iniciales:', error);
  }
};

module.exports = seedInitialData;